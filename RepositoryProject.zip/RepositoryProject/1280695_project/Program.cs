﻿using _1280695_project.Models;
using _1280695_project.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1280695_project
{
    public class Program
    {
        static void Main(string[] args)
        {
            DisplayOptions();
            Console.ReadKey();
        }
        public static void DisplayOptions()
        {
            Console.WriteLine("1 Show All Employee");
            Console.WriteLine("2 Insert Employee");
            Console.WriteLine("3 Update Employee");
            Console.WriteLine("4 Delete Employee");
            var index = int.Parse(Console.ReadLine());
            Show(index);
        }
        public static void Show(int index)
        {
            EmpRepo empRepo = new EmpRepo();

            if (index == 1)
            {
                var empList = empRepo.GetAll();
                if (empList.Count() == 0)
                {
                    Console.WriteLine("=====================================");
                    Console.WriteLine("No item found in the list");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
                else
                {
                    foreach (var item in empRepo.GetAll())
                    {
                        Console.WriteLine($"Employee Id :{item.EmpID},Employee Name :{item.EmpName},Father's Name:{item.FatherName},Mother's Name:{item.MotherName} Age :{item.Age},Designation:{item.Designation},BloodGroup:{item.BloodGroup}");
                    }
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
            }

            else if (index == 2)
            {
                Console.WriteLine("=====================================");

                Console.Write("EmpName :");
                string name = Console.ReadLine();

                Console.Write("FatherName :");
                string fatherName = Console.ReadLine();

                Console.Write("EmpName :");
                string motherName = Console.ReadLine();

                Console.Write("Age :");
                int age = Convert.ToInt32(Console.ReadLine());

                Console.Write("Designation :");
                string designation = Console.ReadLine();

                Console.Write("BloodGroup :");
                string bloodGroup = Console.ReadLine();







                int maxId = empRepo.GetAll().Any() ? empRepo.GetAll().Max(x => x.EmpID) : 0;

                Employee employee = new Employee()
                {
                    EmpID = maxId + 1,
                    EmpName = name,
                    FatherName = fatherName,
                    MotherName = motherName,
                    Age = age,
                    Designation = designation,
                    BloodGroup = bloodGroup
                };
                empRepo.Insert(employee);
                Console.WriteLine("Data Inserted successfully!!!");
                Console.WriteLine("=====================================");
                DisplayOptions();
            }

            else if (index == 3)
            {
                Console.WriteLine("=====================================");
                Console.Write("Entry employee id no to update : ");
                int id = Convert.ToInt32(Console.ReadLine());
                var _employee = empRepo.GetById(id);
                if (_employee == null)
                {
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Employee id is invalid!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                    return;
                }
                else
                {
                    Console.WriteLine($"Update info for employee id :{id}");
                    Console.WriteLine("=====================================");

                    Console.Write("EmpName :");
                    string name = Console.ReadLine();

                    Console.Write("FatherName :");
                    string fatherName = Console.ReadLine();

                    Console.Write("EmpName :");
                    string motherName = Console.ReadLine();

                    Console.Write("Age :");
                    int age = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Designation :");
                    string designation = Console.ReadLine();

                    Console.Write("BloodGroup :");
                    string bloodGroup = Console.ReadLine();




                    Employee employee = new Employee
                    {
                        EmpID = id,
                        EmpName = name,
                        FatherName = fatherName,
                        MotherName = motherName,
                        Age = age,
                        Designation = designation,
                        BloodGroup = bloodGroup

                    };
                    empRepo.Update(employee);
                    Console.WriteLine("Data Updated successfully!!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
            }

            else if (index == 4)
            {
                Console.WriteLine("=====================================");
                Console.Write("Entry employee id no to delete : ");
                int id = Convert.ToInt32(Console.ReadLine());
                var _employee = empRepo.GetById(id);
                if (_employee == null)
                {
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Employee id is invalid!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                    return;
                }
                else
                {
                    empRepo.Delete(id);
                    Console.WriteLine("Data Deleted successfully!!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
            }
        }
    }
}