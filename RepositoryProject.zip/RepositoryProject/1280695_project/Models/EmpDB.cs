﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1280695_project.Models
{
    public class EmpDB
    {
        public static List<Employee> EmployeeList = new List<Employee>();
    }
}
