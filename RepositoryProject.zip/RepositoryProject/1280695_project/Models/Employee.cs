﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1280695_project.Models
{
    public class Employee
    {
        public int EmpID { get; set; }
        public String EmpName { get; set; }
        public string FatherName { get; set; }
        public String MotherName { get; set; }
        public int Age { get; set; }
        public string Designation { get; set; }
        public string BloodGroup { get; set; }
    }
}
