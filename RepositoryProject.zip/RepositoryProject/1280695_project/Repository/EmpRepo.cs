﻿using _1280695_project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1280695_project.Repository
{
    public class EmpRepo : IRepo
    {
        public void Delete(int Id)
        {
            Employee employee = EmpDB.EmployeeList.FirstOrDefault(x => x.EmpID == Id);
            EmpDB.EmployeeList.Remove(employee);
        }

        public IEnumerable<Employee> GetAll()
        {
            return EmpDB.EmployeeList;
        }

        public Employee GetById(int Id)
        {
            Employee employee = EmpDB.EmployeeList.FirstOrDefault(x => x.EmpID == Id);
            return employee;
        }

        public void Insert(Employee employee)
        {
            EmpDB.EmployeeList.Add(employee);
        }

        public void Update(Employee employee)
        {
            Employee _employee = EmpDB.EmployeeList.FirstOrDefault(x => x.EmpID == employee.EmpID);
            if (employee.EmpName != null)
            {
                _employee.EmpName = employee.EmpName;
            }
            if (employee.Age != 0)
            {
                _employee.Age = employee.Age;
            }
        }
    }
}
